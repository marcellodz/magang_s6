// mod/admin/super/js/kegiatanData.js
console.log("[kegiatanData.js] loaded");
window.kegiatanData = {
  1: [
    "Seminar Fakultas Informatika",
    "Seminar Fakultas Teknik Elektro",
    "Trial Class 1: Future Preneur - Siap Jadi Pebisnis di Era AI",
    "Trial Class 2: Decision Making Under Pressure - Jadi Manajer Sehari!",
    "Trial Class 3: The Power of Empathy - Seni Memahami Perasaan Orang Lain",
    "Seminar Parent",
    "Campus Tour - Sesi 1"
  ],
  2: [
    "Seminar Fakultas Rekayasa Industri",
    "Seminar Fakultas Ilmu Terapan",
    "Trial Class 1: Media, Mitos, dan Manipulasi - Siapa yang Mengendalikan Narasi?",
    "Trial Class 2: Smart Health Revolution - Ketika Teknologi Bertemu Tubuh Manusia",
    "Trial Class 3: Data Sains",
    "Campus Tour - Sesi 2",
    "Seminar Double Degree Program"
  ],
  3: [
    "Seminar Fakultas Ekonomi Bisnis",
    "Seminar Fakultas Industri Kreatif",
    "Trial Class 1: AI dan Revolusi Sinema - Ketika Mesin Ikut Berkarya",
    "Trial Class 2: Robot Mini Challenge - Kendalikan Dunia dengan Kode!",
    "Trial Class 3: Tech Meets Business - Membangun Startup Digital dari Nol",
  ],
  4: [
    "Seminar Fakultas Komunikasi dan Ilmu Sosial",
    "Trial Class 1: From Human to Machine - Membangun AI yang Bisa Berpikir",
    "Trial Class 2: Leisure Leadership - Managing People, Places, and Emotions",
    "Trial Class 3: Build Your Own Logistics Startup - Inovasi di Dunia Pengiriman",
    "Seminar Minat Bakat",
    "Campus Tour - Sesi 4"
  ],
  5: [
    "Campus Tour - Sesi 5"
  ]
};
