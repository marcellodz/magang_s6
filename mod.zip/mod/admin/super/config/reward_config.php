<?php
return [
    'facultyTarget' => 7,
    'otherTarget' => 0,
];
