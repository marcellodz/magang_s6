<?php

$conn = mysqli_connect("localhost","root","","newadmissionsitu_db");
if (!$conn){
    die("Koneksi gagal : " . mysqli_connect_error());
}

$conn2 = mysqli_connect("localhost","root","","openhouse_db");
if (!$conn2){
    die("Koneksi gagal : " . mysqli_connect_error());
}

// $conn = mysqli_connect("localhost", "openhouse", "R4xpMyMwjE7HmAHa", "newadmissionSITU");

//if (!$conn) {
//    die("Koneksi gagal: " . mysqli_connect_error());
//}

//$conn2 = mysqli_connect("localhost", "openhouse", "R4xpMyMwjE7HmAHa", "openhouse");

//if (!$conn2) {
//    die("Koneksi gagal: " . mysqli_connect_error());
//}
?>